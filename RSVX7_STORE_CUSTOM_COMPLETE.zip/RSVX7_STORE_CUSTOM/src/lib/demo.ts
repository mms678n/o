import type { Product, ProductCategory } from './types'
const categories = ['Developer Tools', 'Design Assets', 'Productivity', 'Digital Licenses']
export const demoCategories: ProductCategory[] = categories.map((name, idx) => ({ id: 100 + idx, name, slug: name.toLowerCase().replaceAll(' ', '-') }))
const products = [
  ['RSVX7 Studio Suite', 'An elegant digital workspace for creative workflows.', 39, 0],
  ['Nebula UI System', 'Premium interface components and design resources.', 29, 1],
  ['Orbit Developer Kit', 'Reusable utilities for modern application teams.', 49, 0],
  ['Vector Icon Collection', 'Carefully designed scalable interface graphics.', 19, 1],
  ['Focus Workflow Pack', 'Organize and streamline your everyday digital work.', 24, 2],
  ['Atlas Creative Bundle', 'A curated set of digital design essentials.', 59, 1],
] as const
export const demoProducts: Product[] = products.map(([name, summary, dollars, cat], i) => ({
  id: -(i + 1), name, slug: name.toLowerCase().replaceAll(' ', '-'), short_description: summary,
  description: summary, images: [], categories: [demoCategories[cat]], is_purchasable: false,
  is_in_stock: false, demo: true, type: 'simple',
  prices: { currency_code: 'USD', currency_symbol: '$', currency_minor_unit: 2, price: String(dollars * 100) },
}))
