export interface ProductImage { id?: number; src: string; alt?: string; thumbnail?: string }
export interface ProductPrices {
  price: string; regular_price?: string; sale_price?: string;
  currency_code: string; currency_minor_unit: number; currency_symbol?: string
}
export interface ProductCategory { id: number; name: string; slug: string; count?: number }
export interface Product {
  id: number; name: string; slug: string; description?: string; short_description?: string;
  images: ProductImage[]; prices: ProductPrices; categories?: ProductCategory[];
  is_purchasable?: boolean; is_in_stock?: boolean; type?: string;
  has_options?: boolean; is_on_sale?: boolean; is_featured?: boolean; average_rating?: string;
  variation?: unknown[]; permalink?: string; demo?: boolean
}
export interface CartItem {
  key: string; id: number; name: string; quantity: number; images: ProductImage[];
  prices: ProductPrices; totals?: { line_total: string; line_subtotal: string; line_total_tax?: string };
  quantity_limits?: { minimum: number; maximum: number; editable: boolean }
}
export interface Cart {
  items: CartItem[]; items_count: number;
  totals: { total_price: string; total_items?: string; total_tax?: string; currency_code: string; currency_minor_unit: number; currency_symbol?: string };
  payment_methods?: string[];
  errors?: { code: string; message: string }[]
}
