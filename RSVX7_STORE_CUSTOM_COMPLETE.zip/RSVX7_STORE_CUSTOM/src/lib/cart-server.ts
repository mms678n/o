import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { demoMode, storeBase } from './woocommerce'

const cookieName = 'rsvx7_wc_cart'
export function problem(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status, headers: { 'Cache-Control': 'no-store' } })
}
export async function proxyWoo(path: string, method: 'GET' | 'POST', body?: unknown) {
  if (demoMode) return problem('Demo mode: connect WooCommerce before using cart or checkout.', 409)
  const jar = await cookies()
  const token = jar.get(cookieName)?.value
  const headers: Record<string,string> = { Accept: 'application/json', 'X-Forwarded-Proto': 'https', Host: new URL(process.env.WP_PUBLIC_URL || 'https://preview.rsvx7-store.com').host }
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  if (token) headers['Cart-Token'] = token
  try {
    const remote = await fetch(`${storeBase}${path}`, {
      method, headers, body: body === undefined ? undefined : JSON.stringify(body),
      cache: 'no-store', redirect: 'manual', signal: AbortSignal.timeout(15000),
    })
    const raw = await remote.text()
    let data: unknown
    try { data = JSON.parse(raw) } catch { return problem('WooCommerce returned an invalid response. Check internal networking.', 502) }
    const response = NextResponse.json(data, { status: remote.status, headers: { 'Cache-Control': 'no-store' } })
    const nextToken = remote.headers.get('cart-token')
    if (nextToken && nextToken.length < 4096) response.cookies.set(cookieName, nextToken, {
      httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax',
      path: '/', maxAge: 60 * 60 * 24 * 14,
    })
    return response
  } catch (error) {
    console.error('WooCommerce request failure:', error)
    return problem('Cannot reach WooCommerce. Check Docker networking and WooCommerce status.', 503)
  }
}
