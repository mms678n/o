'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { ShoppingBag, LoaderCircle } from 'lucide-react'
import type { Product } from '@/lib/types'
export function AddToCart({product}:{product:Product}){
 const [busy,setBusy]=useState(false);const [error,setError]=useState('');const router=useRouter()
 const supported=product.type==='simple' && product.is_purchasable === true && product.is_in_stock!==false && !product.demo && !product.has_options
 async function add(){setBusy(true);setError('');try{
   // Obtain an anonymous Cart-Token and keep it in an HttpOnly cookie.
   const initial=await fetch('/api/cart',{credentials:'same-origin',cache:'no-store'})
   if(!initial.ok) throw new Error((await initial.json()).error||'Cart unavailable')
   const resp=await fetch('/api/cart/add',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({id:product.id,quantity:1})})
   const json=await resp.json();if(!resp.ok)throw new Error(json.message||json.error||'Could not add item')
   router.push('/cart');router.refresh()
 }catch(err){setError(err instanceof Error?err.message:'Unable to update cart')}finally{setBusy(false)}}
 return <div><button className="button button-light full" disabled={!supported||busy} onClick={add}>{busy?<LoaderCircle className="spin" size={20}/>:<ShoppingBag size={20}/>} {product.demo?'DEMO PRODUCT':!supported?'UNAVAILABLE OR REQUIRES OPTIONS':'ADD TO CART'}</button>{error&&<p className="error-text" role="alert">{error}</p>}{!supported&&!product.demo&&<p className="muted-note">Simple, purchasable WooCommerce products are supported. For variable products, choose options in WordPress until variant support is enabled.</p>}</div>
}
