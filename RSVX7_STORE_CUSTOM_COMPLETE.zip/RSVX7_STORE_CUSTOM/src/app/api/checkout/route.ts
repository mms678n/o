import { problem, proxyWoo } from '@/lib/cart-server'
export const dynamic = 'force-dynamic'
const allowed = new Set((process.env.WC_ALLOWED_CHECKOUT_METHODS || 'bacs,cheque').split(',').map(s => s.trim()).filter(Boolean))
export async function POST(req: Request) {
  const origin = req.headers.get('origin')
  if (origin) { try { if (new URL(origin).host !== req.headers.get('host')) return problem('Origin not allowed', 403) } catch { return problem('Invalid origin', 403) } }
  let data: Record<string, unknown>
  try { data = await req.json() } catch { return problem('Invalid JSON') }
  if (!data || typeof data !== 'object' || Array.isArray(data)) return problem('Invalid checkout request')
  const payment = data.payment_method
  if (typeof payment !== 'string' || !allowed.has(payment)) return problem('This payment method is not enabled for headless checkout.')
  const b = data.billing_address
  if (!b || typeof b !== 'object' || Array.isArray(b)) return problem('Billing address is required')
  const billing = b as Record<string, unknown>
  for (const field of ['first_name','last_name','email','country']) {
    if (typeof billing[field] !== 'string' || !(billing[field] as string).trim() || (billing[field] as string).length > 160) return problem(`Invalid billing ${field}`)
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(billing.email))) return problem('Invalid email')
  const fields = ['first_name','last_name','company','address_1','address_2','city','state','postcode','country','email','phone']
  const address: Record<string,string> = {}
  for (const field of fields) {
    const value = billing[field]
    if (value !== undefined && (typeof value !== 'string' || value.length > 160)) return problem('Invalid billing field')
    address[field] = typeof value === 'string' ? value.trim() : ''
  }
  // We send shipping_address too, as required by Woo checkout, even for digital-only carts.
  const payload = { billing_address: address, shipping_address: address, payment_method: payment,
    payment_data: [], customer_note: '',
    ...(typeof data.expected_total === 'string' && /^\d{1,20}$/.test(data.expected_total) ? { expected_total: data.expected_total } : {}) }
  return proxyWoo('/checkout', 'POST', payload)
}
