import { problem, proxyWoo } from '@/lib/cart-server'
export const dynamic = 'force-dynamic'
const pathMap: Record<string, string> = { add: 'add-item', update: 'update-item', remove: 'remove-item', coupon: 'apply-coupon' }
export async function POST(req: Request, { params }: { params: Promise<{ action: string }> }) {
  const origin = req.headers.get('origin')
  if (origin) { try { if (new URL(origin).host !== req.headers.get('host')) return problem('Origin not allowed', 403) } catch { return problem('Invalid origin', 403) } }
  const { action } = await params
  if (!Object.prototype.hasOwnProperty.call(pathMap, action)) return problem('Unknown action', 404)
  let body: Record<string, unknown>
  try { body = await req.json() } catch { return problem('Invalid JSON request') }
  if (!body || typeof body !== 'object' || Array.isArray(body)) return problem('Invalid request')
  if (action === 'add') {
    if (typeof body.id !== 'number' || !Number.isSafeInteger(body.id) || body.id < 1 || typeof body.quantity !== 'number' || !Number.isInteger(body.quantity) || body.quantity < 1 || body.quantity > 99) return problem('Invalid product or quantity')
    if (body.variation !== undefined && (!Array.isArray(body.variation) || body.variation.length > 10 || !body.variation.every((v: unknown) => typeof v === 'object' && v !== null && typeof (v as Record<string,unknown>).attribute === 'string' && typeof (v as Record<string,unknown>).value === 'string'))) return problem('Invalid variant selection')
    body = { id: body.id, quantity: body.quantity, ...(body.variation ? { variation: body.variation } : {}) }
  } else if (action === 'update') {
    if (typeof body.key !== 'string' || !/^[a-zA-Z0-9_-]{1,128}$/.test(body.key) || typeof body.quantity !== 'number' || !Number.isInteger(body.quantity) || body.quantity < 1 || body.quantity > 99) return problem('Invalid cart update')
    body = { key: body.key, quantity: body.quantity }
  } else if (action === 'remove') {
    if (typeof body.key !== 'string' || !/^[a-zA-Z0-9_-]{1,128}$/.test(body.key)) return problem('Invalid cart item')
    body = { key: body.key }
  } else {
    if (typeof body.code !== 'string' || body.code.length > 80 || !/^[\w-]+$/.test(body.code)) return problem('Invalid coupon')
    body = { code: body.code }
  }
  return proxyWoo(`/cart/${pathMap[action]}`, 'POST', body)
}
