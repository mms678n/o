import { proxyWoo } from '@/lib/cart-server'
export const dynamic = 'force-dynamic'
export async function GET() { return proxyWoo('/cart', 'GET') }
