import Link from 'next/link'
export default function NotFound(){return <main className="page-main"><div className="container"><div className="page-intro"><span className="eyebrow">404 / NOT FOUND</span><h1>LOST IN <span>SPACE.</span></h1><p>The page or product you requested is not available.</p><Link className="button button-light" href="/shop">BACK TO THE STORE ↗</Link></div></div></main>}
