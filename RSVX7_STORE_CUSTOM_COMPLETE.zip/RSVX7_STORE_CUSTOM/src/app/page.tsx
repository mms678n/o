import Link from 'next/link'
import Image from 'next/image'
import { ArrowUpRight, Box, Download, ShieldCheck, Zap, Sparkles } from 'lucide-react'
import { Hero } from '@/components/hero'
import { Reveal } from '@/components/reveal'
import { ProductSection } from '@/components/product-section'
import { getCategories, getProducts, demoMode } from '@/lib/woocommerce'
export const dynamic = 'force-dynamic'
export default async function Home(){const [products,cats]=await Promise.all([getProducts({perPage:6}),getCategories()]);return <main>
 <Hero/>
 <div className="ticker" aria-label="Store values"><div className="ticker-track" aria-hidden="true">{Array.from({length:3},(_,i)=><span key={i}>DESIGNED FOR DIGITAL <span>✳</span> CURATED WITH PURPOSE <span>✳</span> EXPLORE THE UNEXPECTED <span>✳</span> </span>)}</div></div>
 <div className="container trust-band"><span><Zap size={18}/> DIGITAL-FIRST EXPERIENCE</span><span><ShieldCheck size={18}/> SECURE CHECKOUT THROUGH WOOCOMMERCE</span><span><Download size={18}/> DELIVERY VIA YOUR STORE</span></div>
 {demoMode&&<div className="container"><p className="demo-banner">DEMO MODE — Sample products and prices for design preview. Purchasing is disabled until WooCommerce is connected.</p></div>}
 <ProductSection products={products}/>
 <section className="feature-section"><div className="container feature-grid"><Reveal className="feature-copy"><span className="eyebrow"><span className="mini-square"/> BEYOND ORDINARY</span><h2>NOT JUST<br/>ANOTHER <em>STORE.</em></h2><p>A considered space for digital essentials. Every detail is crafted to make discovering, choosing, and using great tools feel effortless.</p><Link className="button button-dark" href="/about">MORE ABOUT US <ArrowUpRight size={19}/></Link></Reveal><Reveal className="feature-display" delay={.15}><div className="feature-frame"><div className="feature-frame-top"><span>RSVX7 / SYSTEM</span><span>2026 — ∞</span></div><div className="feature-symbol"><Image src="/logo-mark.png" alt="" width={190} height={190}/></div><div className="feature-frame-bottom"><span>SHAPE WHAT'S NEXT</span><Sparkles size={23}/></div></div></Reveal></div></section>
 <section className="category-section" id="categories"><div className="container"><Reveal className="section-heading"><div><span className="eyebrow"><span className="mini-square"/> FIND YOUR NEXT TOOL</span><h2>EXPLORE CATEGORIES<span className="period">.</span></h2></div></Reveal><div className="category-grid">{(cats.length?cats:[{id:1,name:'Discover the store',slug:'all'}]).slice(0,4).map((c,i)=><Link key={c.id} className="category-tile" href={c.slug==='all'?'/shop':`/shop?category=${c.id}`}><span className="cat-id">0{i+1} / COLLECTION</span><span className="cat-label">{c.name}</span><span className="cat-bottom"><Box size={24}/><ArrowUpRight size={23}/></span></Link>)}</div></div></section>
 <section className="closing-section"><div className="container closing-content"><Reveal><span className="eyebrow">A BETTER DIGITAL DESTINATION</span><h2>CREATE MORE.<br/><span>COMPROMISE LESS.</span></h2><Link className="button button-light" href="/shop">BROWSE ALL PRODUCTS <ArrowUpRight size={20}/></Link></Reveal><span className="closing-asterisk" aria-hidden="true">✳</span></div></section>
 </main>}
