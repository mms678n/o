from pathlib import Path
root=Path(__file__).resolve().parents[1]
required=['package.json','Dockerfile','compose.yaml','src/app/page.tsx','src/app/globals.css','src/app/shop/page.tsx','src/app/products/[slug]/page.tsx','src/app/cart/page.tsx','src/app/checkout/page.tsx','src/app/account/page.tsx','src/app/wallet/page.tsx','src/app/api/health/route.ts','src/app/api/cart/[action]/route.ts','src/app/api/media/route.ts','src/lib/woocommerce.ts','preview/preview.html','public/logo-mark.png','deploy/install.sh','README_AR.md']
missing=[r for r in required if not (root/r).is_file()]
assert not missing, f'Missing files: {missing}'
assert 'DEMO_MODE' in (root/'src/lib/woocommerce.ts').read_text()
assert 'httpOnly: true' in (root/'src/lib/cart-server.ts').read_text()
assert 'basic_auth' in (root/'deploy/install.sh').read_text()
assert 'reverse_proxy rsvx7-custom-ui:3000' in (root/'deploy/install.sh').read_text()
assert 'docker compose down -v' not in (root/'deploy/install.sh').read_text()
print(f'Structure check passed: {len(required)} required files')
