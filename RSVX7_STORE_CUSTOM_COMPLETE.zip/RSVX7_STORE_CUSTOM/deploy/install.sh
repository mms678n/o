#!/usr/bin/env bash
# Run as root from the extracted archive. Installs alongside existing WordPress/Medusa.
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$HERE"
WP_ENV="/root/rsvx7-wordpress/.env"
CADDY_NAME="digital-store-caddy-1"
DOMAIN="ui.rsvx7-store.com"
if [[ ! -f "$WP_ENV" ]]; then echo "ERROR: WordPress env missing ($WP_ENV)" >&2; exit 1; fi
if ! docker inspect "$CADDY_NAME" >/dev/null 2>&1; then echo "ERROR: Existing Caddy container missing" >&2; exit 1; fi
NETWORK="$(sed -n 's/^CADDY_NET=//p' "$WP_ENV" | tr -d '\r' | tail -n 1)"
if [[ -z "$NETWORK" ]]; then echo 'ERROR: Cannot find CADDY_NET'; exit 1; fi
if ! docker network inspect "$NETWORK" >/dev/null 2>&1; then echo 'ERROR: Caddy network not found'; exit 1; fi
if [[ -f .env ]]; then
  echo 'Existing .env preserved.'
else
  umask 077
  cat > .env <<ENV
CADDY_NET=$NETWORK
DEMO_MODE=false
WC_INTERNAL_URL=http://rsvx7-wp-wordpress-1
WP_PUBLIC_URL=https://preview.rsvx7-store.com
WC_ALLOWED_CHECKOUT_METHODS=bacs,cheque
ENV
fi
# Build first, before making any change to Caddy.
docker compose config --quiet
docker compose up -d --build
for i in $(seq 1 25); do
  HTTP="$(curl -fsS --max-time 4 -o /dev/null -w '%{http_code}' http://127.0.0.1:3010/api/health || true)"
  [[ "$HTTP" == '200' ]] && break
  sleep 3
done
if [[ "$HTTP" != '200' ]]; then echo 'ERROR: UI health check failed, leaving Caddy unchanged'; exit 1; fi
CF="$(docker inspect "$CADDY_NAME" | python3 -c '
import sys,json,os
x=json.load(sys.stdin)[0]["Mounts"]
for m in x:
 if m.get("Type") != "bind": continue
 if m["Destination"] == "/etc/caddy/Caddyfile": print(m["Source"]); break
 if m["Destination"] == "/etc/caddy": print(os.path.join(m["Source"],"Caddyfile")); break
')"
if [[ ! -f "$CF" ]]; then echo 'ERROR: Caddyfile bind mount not found, leaving Caddy unchanged'; exit 1; fi
if grep -Fq "$DOMAIN" "$CF"; then
 echo 'UI domain already exists in Caddy. Skipping Caddy changes.'
else
 umask 077
 SECRET="$(openssl rand -hex 14)"
 HASH="$(docker exec "$CADDY_NAME" caddy hash-password --plaintext "$SECRET")"
 BACKUP="$CF.rsvx7-ui-backup-$(date +%Y%m%d-%H%M%S)"
 cp -a "$CF" "$BACKUP"
 cat >> "$CF" <<CADDY

$DOMAIN {
  encode zstd gzip
  header X-Robots-Tag "noindex, nofollow"
  basic_auth {
    preview $HASH
  }
  reverse_proxy rsvx7-custom-ui:3000
}
CADDY
 if ! docker exec "$CADDY_NAME" caddy validate --config /etc/caddy/Caddyfile || ! docker exec "$CADDY_NAME" caddy reload --config /etc/caddy/Caddyfile; then
  cp -a "$BACKUP" "$CF"
  docker exec "$CADDY_NAME" caddy reload --config /etc/caddy/Caddyfile || true
  echo 'ERROR: Caddy validation/reload failed. Original config restored.' >&2
  exit 1
 fi
 printf 'Preview URL: https://%s\nUsername: preview\nPassword: %s\n' "$DOMAIN" "$SECRET" > ui-access.txt
 chmod 600 ui-access.txt
fi
printf '\nFrontend health: %s\n' "$HTTP"
printf 'Local preview: http://127.0.0.1:3010\nProtected domain: https://%s\n' "$DOMAIN"
if [[ -f ui-access.txt ]];then echo 'Preview login saved in ui-access.txt (do not share).';fi
printf 'DNS: create an A record for ui pointing at your server IP.\n'
docker compose ps
