#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo '=== FRONTEND ==='
docker compose ps
echo '=== HEALTH ==='
curl -fsS http://127.0.0.1:3010/api/health; echo
echo '=== HOME ==='
curl -sSL --max-time 30 -o /dev/null -w 'HTTP %{http_code} (%{time_total}s)\n' http://127.0.0.1:3010/
echo '=== WOOCOMMERCE INTERNAL ACCESS ==='
docker exec rsvx7-custom-ui node -e 'fetch(process.env.WC_INTERNAL_URL+"/wp-json/wc/store/v1/products?per_page=1").then(async r=>{console.log("Store API HTTP",r.status);console.log((await r.text()).slice(0,160))}).catch(e=>{console.error(e.message);process.exitCode=1})'
echo '=== RECENT UI LOGS ==='
docker logs --tail=40 rsvx7-custom-ui 2>&1
